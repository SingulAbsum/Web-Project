<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Author Profile - Blogy Bootstrap Template</title>
  <meta name="description" content="">
  <meta name="keywords" content="">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Nunito:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Blogy
  * Template URL: https://bootstrapmade.com/blogy-bootstrap-blog-template/
  * Updated: Feb 22 2025 with Bootstrap v5.3.3
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body class="author-profile-page">

  <?php
 include 'header.php';
 ?>

  <main class="main">

    <!-- Page Title -->
    <div class="page-title">
      <div class="breadcrumbs">
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="#"><i class="bi bi-house"></i> Home</a></li>
            <li class="breadcrumb-item"><a href="#">Category</a></li>
            <li class="breadcrumb-item active current">Author Profile</li>
          </ol>
        </nav>
      </div>

      <div class="title-wrapper">
        <h1>Author Profile</h1>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.</p>
      </div>
    </div><!-- End Page Title -->

    <!-- Author Profile Section -->
    <section id="author-profile" class="author-profile section">

      <div class="container" data-aos="fade-up" data-aos-delay="100">

        <div class="author-profile-1">

          <div class="row">
            <!-- Author Info -->
            <div class="col-lg-4 mb-4 mb-lg-0">
              <div class="author-card" data-aos="fade-up">
                <div class="author-image">
                  <img src="assets/img/person/person-m-5.webp" alt="Author" class="img-fluid rounded">
                </div>

                <div class="author-info">
                  <h2>Kevin Anderson</h2>
                  <p class="designation">Senior Technology Writer</p>

                  <div class="author-bio">
                    Through my articles, I explore the intersection of technology and society, focusing on how emerging tech shapes our daily lives and future possibilities.
                  </div>

                  <div class="author-stats d-flex justify-content-between text-center my-4">
                    <div class="stat-item">
                      <h4 data-purecounter-start="0" data-purecounter-end="147" data-purecounter-duration="1" class="purecounter"></h4>
                      <p>Articles</p>
                    </div>
                    <div class="stat-item">
                      <h4 data-purecounter-start="0" data-purecounter-end="13" data-purecounter-duration="1" class="purecounter"></h4>
                      <p>Awards</p>
                    </div>
                    <div class="stat-item">
                      <h4 data-purecounter-start="0" data-purecounter-end="25" data-purecounter-duration="1" class="purecounter">K</h4>
                      <p>Followers</p>
                    </div>
                  </div>

                  <div class="social-links">
                    <a href="#" class="twitter"><i class="bi bi-twitter-x"></i></a>
                    <a href="#" class="facebook"><i class="bi bi-facebook"></i></a>
                    <a href="#" class="instagram"><i class="bi bi-instagram"></i></a>
                    <a href="#" class="linkedin"><i class="bi bi-linkedin"></i></a>
                  </div>
                </div>
              </div>
            </div>

            <!-- Author Content -->
            <div class="col-lg-8">
              <div class="author-content" data-aos="fade-up" data-aos-delay="200">
                <div class="content-header">
                  <h3>About Me</h3>
                </div>
                <div class="content-body">
                  <p>With over a decade of experience in technology journalism, I've had the privilege of witnessing and documenting the rapid evolution of our digital landscape. My work spans from in-depth analysis of artificial intelligence and its implications to hands-on reviews of the latest consumer technology.</p>

                  <div class="expertise-areas">
                    <h4>Areas of Expertise</h4>
                    <div class="tags">
                      <span>Artificial Intelligence</span>
                      <span>Cybersecurity</span>
                      <span>Smart Home Technology</span>
                      <span>Digital Privacy</span>
                      <span>Consumer Electronics</span>
                      <span>Future Tech Trends</span>
                    </div>
                  </div>

                  <div class="featured-articles mt-5">
                    <h4>Featured Articles</h4>
                    <div class="row g-4">
                      <div class="col-md-6" data-aos="fade-up" data-aos-delay="300">
                        <article class="article-card">
                          <div class="article-img">
                            <img src="assets/img/blog/blog-post-10.webp" alt="Article" class="img-fluid">
                          </div>
                          <div class="article-details">
                            <div class="post-category">Technology</div>
                            <h5><a href="#">The Future of AI in Everyday Computing</a></h5>
                            <div class="post-meta">
                              <span><i class="bi bi-clock"></i> Jan 15, 2024</span>
                              <span><i class="bi bi-chat-dots"></i> 24 Comments</span>
                            </div>
                          </div>
                        </article>
                      </div>

                      <div class="col-md-6" data-aos="fade-up" data-aos-delay="400">
                        <article class="article-card">
                          <div class="article-img">
                            <img src="assets/img/blog/blog-post-6.webp" alt="Article" class="img-fluid">
                          </div>
                          <div class="article-details">
                            <div class="post-category">Privacy</div>
                            <h5><a href="#">Understanding Digital Privacy in 2024</a></h5>
                            <div class="post-meta">
                              <span><i class="bi bi-clock"></i> Feb 3, 2024</span>
                              <span><i class="bi bi-chat-dots"></i> 18 Comments</span>
                            </div>
                          </div>
                        </article>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

          </div>

        </div>

      </div>

    </section><!-- /Author Profile Section -->

  </main>

  <?php
 include 'footer.php';
 ?>


  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Preloader -->
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>

  <!-- Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>
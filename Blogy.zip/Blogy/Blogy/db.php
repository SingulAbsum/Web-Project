<?php
$pdo=new PDO("mysql:host=localhost;dbname=test","root","");
function insert($role,$username,$password){
    global $pdo;
$stmt=$pdo->prepare("INSERT INTO $role (username,password) VALUES (:u,:p)");
$stmt->execute([
    'u'=>$username,
    'p'=>$password
]);
}
function checkLogin($r,$username){
    global $pdo;
 $checkLogin=$pdo->prepare("SELECT username,password FROM $r WHERE username=:u");
 $checkLogin->execute([
    'u'=>$username
 ]);
 function add($img){
    global $pdo;
 $checkLogin=$pdo->prepare("INSERT INTO user (img) VALUES(:u)");
 $checkLogin->execute([
    'u'=>$img
 ]);
 return $checkLogin->fetch(PDO::FETCH_ASSOC);
}

?>
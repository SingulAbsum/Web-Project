<?php
$pdo=new PDO("mysql:host=localhost;dbname=test","root","");
$role=$_SESSION['role'];
$username=$_SESSION['username'];
function insert($role,$username,$password){
    global $pdo;
$stmt=$pdo->prepare("INSERT INTO $role (username,password) VALUES (:u,:p)");
$stmt->execute([
    'u'=>$username,
    'p'=>$password
]);
}
function checkLogin($r,$username){
    global $pdo;
 $checkLogin=$pdo->prepare("SELECT username,password FROM $r WHERE username=:u");
 $checkLogin->execute([
    'u'=>$username
 ]);
  return $checkLogin->fetch(PDO::FETCH_ASSOC);
}
function checkToken($r,$username){
    global $pdo;
 $checkLogin=$pdo->prepare("SELECT token FROM $r WHERE username=:u");
 $checkLogin->execute([
    'u'=>$username
 ]);
  return $checkLogin->fetch(PDO::FETCH_ASSOC);
}
 function addImg($img){
    global $pdo;
 $checkLogin=$pdo->prepare("INSERT INTO user (img) VALUES(:u)");
 $checkLogin->execute([
    'u'=>$img
 ]);
}
 function addToken($token){
    global $pdo;
    global $role;
    global $username;
 $checkLogin=$pdo->prepare("UPDATE $role SET token=:t WHERE username=:u");
 $checkLogin->execute([
    't'=>$token,
    'u'=>$username
 ]);
 }
?>
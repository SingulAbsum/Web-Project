<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login | MySite</title>
    <link rel="stylesheet" href="login.css">
</head>
<body>
<div class="login-container">
<h2>Register</h2>
<form method="post" action="">
<div class="form-group">
            <label for="username">Username</label>
            <input type="text" name="username" id="username" required autocomplete="off">
        </div>
        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" name="password" id="password" required autocomplete="off">
        </div>
        <label>
        <input type="radio" name="role" value="user">
        user
    </label>
    <label style="margin-left: 20px;">
        <input type="radio" name="role" value="admin">
        administrator
    </label>
    <button type="submit" class="login-btn">Create New</button>
    <?php
    require 'db.php';
    try{
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    $role = $_POST['role'] ?? '';
    $hpassword=password_hash($password,PASSWORD_DEFAULT);
    insert($role,$username,$hpassword);
    header("index.php");
}
    }
catch (PDOException $e) {
    echo "❌ Error: " . $e->getMessage();
}
?>

</form>
</div>
</body>
</html>
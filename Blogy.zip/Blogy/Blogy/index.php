<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login | MySite</title>
    <link rel="stylesheet" href="login.css">
</head>
<body>

<div class="login-container">
    <h2>Login</h2>
    <form method="post" action="">
        <div class="form-group">
            <label for="username">Username</label>
            <input type="text" name="username" id="username" required autocomplete="off">
        </div>
        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" name="password" id="password" required autocomplete="off">
            <label>
        </div>
        <input type="radio" name="role" value="user">
        user
    </label>

    <label style="margin-left: 20px;">
        <input type="radio" name="role" value="administrator">
        administrator
    </label>
    <input type="button" onclick="window.location.href='register.php'" class="login-btn" value="create new">

        <button type="submit" class="login-btn">Sign In</button>

        <?php
        if(isset($_SESSION['username'])){
            header("Location: home.php");
            exit();
        }
        if ($_SERVER["REQUEST_METHOD"] === "POST") {
            $u = $_POST['username'] ?? '';
            $p = $_POST['password'] ?? '';
            $r = $_POST['role'] ?? '';
require 'db.php';
            $results=checkLogin($r,$u);
            if($results){
                echo $p;
                echo $results['password'];
                if(password_verify($p,$results['password'])){
                    $_SESSION['username']=$u;
                    header('Location: home.php');
                    exit();
                }
                else{
                    echo 'incorrect';
                }
            }
            else{
                echo 'invalid';
            }
        }
        ?>
    </form>
</div>

</body>
</html>

<?php
        session_start();
          require 'db.php';
        $token = $_GET['token'] ?? '';
        $_SESSION['delete_token'] = bin2hex(random_bytes(32));
        addToken($_SESSION['delete_token']);
        $tk=checkToken($_SESSION['role'],$_SESSION['username']);
    if ($token !== '') {
    if ($tk && hash_equals($tk['token'], $token)) {
        session_destroy();
        header('Location: index.php');
        exit();
    } else {
        echo "Invalid token. Action denied.";
        exit();
    }
}
else{
    session_destroy();
        header('Location: index.php');
        exit();
}
?>
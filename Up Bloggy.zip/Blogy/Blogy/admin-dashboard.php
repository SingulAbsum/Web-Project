<?php

session_start();
error_reporting(E_ALL & ~E_WARNING);
include 'db.php';

// Check admin login (you should improve this later with real auth)
if($_SESSION['role']!='admin' || $_SESSION['guest']=='on' || $_SESSION['guest']=='off'){
  header("Location:index.php");
  exit();
}
if(!isset($_SESSION['username']) && $_SESSION['role']=="user"){
  header("Location: index.php");
  exit();
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {

if (isset($_POST['add_article'])) {

$stmt = $pdo->prepare("INSERT INTO articles (title, content, full_content, poster_id, category, type, img, subtype)

VALUES (:title, :content, :full_content, :poster_id, :category, :type, :img, :subtype)");

$stmt->execute([

':title' => $_POST['title'],

':content' => $_POST['content'],

':full_content' => $_POST['full_content'],

':poster_id' => $_POST['poster_id'],

':category' => $_POST['category'],

':type' => $_POST['type'],

':img' => $_POST['img'],

':subtype' => $_POST['subtype']

]);

}



if (isset($_POST['edit_article'])) {

$stmt = $pdo->prepare("UPDATE articles

SET title=:title, content=:content, full_content=:full_content, category=:category,

type=:type, img=:img, subtype=:subtype

WHERE id=:id");

$stmt->execute([

':title' => $_POST['title'],

':content' => $_POST['content'],

':full_content' => $_POST['full_content'],

':category' => $_POST['category'],

':type' => $_POST['type'],

':img' => $_POST['img'],

':subtype' => $_POST['subtype'],

':id' => $_POST['id']

]);

}



if (isset($_POST['delete_article'])) {

$stmt = $pdo->prepare("DELETE FROM articles WHERE id = :id");

$stmt->execute([':id' => $_POST['id']]);

}


if (isset($_POST['add_user'])) {

$stmt = $pdo->prepare("INSERT INTO users (`full name`, email, username, password, role, img, personal_description)

VALUES (:fullname, :email, :username, :password, 'poster', :img, :description)");

$stmt->execute([

':fullname' => $_POST['fullname'],

':email' => $_POST['email'],

':username' => $_POST['username'],

':password' => password_hash($_POST['password'], PASSWORD_BCRYPT),

':img' => $_POST['img'],

':description' => $_POST['description']

]);

}



if (isset($_POST['delete_user'])) {

$stmt = $pdo->prepare("DELETE FROM users WHERE id = :id");

$stmt->execute([':id' => $_POST['id']]);

}

}


$articles = $pdo->query("SELECT * FROM articles")->fetchAll(PDO::FETCH_ASSOC);

$users = $pdo->query("SELECT * FROM users WHERE role='poster'")->fetchAll(PDO::FETCH_ASSOC);

$categories = ['Lifestyle', 'Travel', 'Design', 'Creative', 'Education'];

?>


<!DOCTYPE html>

<html>

<head>

<title>Admin Dashboard</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body class="p-4">

<div class="container">

<div class="d-flex justify-content-between align-items-center mb-4">

<h2>Admin Dashboard</h2>

<a href="logout.php" class="btn btn-outline-secondary">Logout</a>

</div>


<!-- News Articles Table -->

<div class="mb-5">

<h4>News Articles</h4>

<button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#addArticleModal">Add Article</button>

<table class="table table-bordered">

<thead><tr><th>ID</th><th>Title</th><th>Status</th><th>Category</th><th>Actions</th></tr></thead>

<tbody>

<?php foreach($articles as $row): ?>

<tr>

<td><?= $row['id'] ?></td>

<td><?= htmlspecialchars($row['title']) ?></td>

<td><?= $row['status'] ?></td>

<td><?= $row['category'] ?></td>

<td>

<button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#editArticleModal<?= $row['id'] ?>">Edit</button>

<form method="post" class="d-inline">

<input type="hidden" name="id" value="<?= $row['id'] ?>">

<button name="delete_article" class="btn btn-sm btn-danger" onclick="return confirm('Delete this article?')">Delete</button>

</form>

</td>

</tr>

<?php endforeach; ?>

</tbody>

</table>

</div>


<!-- Users Table -->

<div>

<h4>Poster Users</h4>

<button class="btn btn-success mb-3" data-bs-toggle="modal" data-bs-target="#addUserModal">Add User</button>

<table class="table table-bordered">

<thead><tr><th>ID</th><th>Full Name</th><th>Email</th><th>Username</th><th>Actions</th></tr></thead>

<tbody>

<?php foreach($users as $user): ?>

<tr>

<td><?= $user['id'] ?></td>

<td><?= htmlspecialchars($user['full name']) ?></td>

<td><?= htmlspecialchars($user['email']) ?></td>

<td><?= htmlspecialchars($user['username']) ?></td>

<td>

<form method="post" class="d-inline">

<input type="hidden" name="id" value="<?= $user['id'] ?>">

<button name="delete_user" class="btn btn-sm btn-danger" onclick="return confirm('Delete this user?')">Delete</button>

</form>

</td>

</tr>

<?php endforeach; ?>

</tbody>

</table>

</div>

</div>


<!-- Add Article Modal -->

<div class="modal fade" id="addArticleModal" tabindex="-1">

<div class="modal-dialog">

<form method="post" class="modal-content">

<div class="modal-header"><h5 class="modal-title">Add New Article</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>

<div class="modal-body">

<input type="text" name="title" class="form-control mb-2" placeholder="Title" required>

<textarea name="content" class="form-control mb-2" placeholder="Short Content" required></textarea>

<textarea name="full_content" class="form-control mb-2" placeholder="Full Content"></textarea>

<input type="text" name="poster_id" class="form-control mb-2" placeholder="poster_id" required>

<select name="category" class="form-control mb-2" required>

<?php foreach ($categories as $cat): ?>

<option value="<?= $cat ?>"><?= $cat ?></option>

<?php endforeach; ?>

</select>

<input type="text" name="type" class="form-control mb-2" placeholder="Type (e.g., featured, category)" required>

<input type="text" name="img" class="form-control mb-2" placeholder="Image filename (e.g., blog.jpg)" required>

<input type="text" name="subtype" class="form-control mb-2" placeholder="Subtype (e.g., featured, unfeatured)" required>


</div>

<div class="modal-footer">

<button type="submit" name="add_article" class="btn btn-primary">Add Article</button>

<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>

</div>

</form>

</div>

</div>


<!-- Add User Modal -->

<div class="modal fade" id="addUserModal" tabindex="-1">

<div class="modal-dialog">

<form method="post" class="modal-content">

<div class="modal-header"><h5 class="modal-title">Add New User</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>

<div class="modal-body">

<input type="text" name="fullname" class="form-control mb-2" placeholder="Full Name" required>

<input type="email" name="email" class="form-control mb-2" placeholder="Email" required>

<input type="text" name="username" class="form-control mb-2" placeholder="Username" required>

<input type="password" name="password" class="form-control mb-2" placeholder="Password" required>

<input type="text" name="img" class="form-control mb-2" placeholder="Image filename (e.g., avatar.jpg)">

<textarea name="description" class="form-control mb-2" placeholder="Personal Description"></textarea>


</div>

<div class="modal-footer">

<button type="submit" name="add_user" class="btn btn-success">Add User</button>

<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>

</div>

</form>

</div>

</div>


<!-- Edit Article Modals -->

<?php foreach($articles as $row): ?>

<div class="modal fade" id="editArticleModal<?= $row['id'] ?>" tabindex="-1">

<div class="modal-dialog">

<form method="post" class="modal-content">

<div class="modal-header">

<h5 class="modal-title">Edit Article</h5>

<button type="button" class="btn-close" data-bs-dismiss="modal"></button>

</div>

<div class="modal-body">

<input type="hidden" name="id" value="<?= $row['id'] ?>">

<input type="text" name="title" class="form-control mb-2" value="<?= htmlspecialchars($row['title'], ENT_QUOTES | ENT_HTML5) ?>" required>

<textarea name="content" class="form-control mb-2" required><?= htmlspecialchars($row['content'], ENT_QUOTES | ENT_HTML5) ?></textarea>

<textarea name="full_content" class="form-control mb-2"><?= htmlspecialchars($row['full_content'], ENT_QUOTES | ENT_HTML5) ?></textarea>

<select name="category" class="form-control mb-2">

<?php foreach ($categories as $cat): ?>

<option value="<?= $cat ?>" <?= $cat == $row['category'] ? 'selected' : '' ?>><?= $cat ?></option>

<?php endforeach; ?>

</select>

<input type="text" name="type" class="form-control mb-2" value="<?= htmlspecialchars($row['type']) ?>" required>

<input type="text" name="img" class="form-control mb-2" value="<?= htmlspecialchars($row['img']) ?>" required>

<input type="text" name="subtype" class="form-control mb-2" value="<?= htmlspecialchars($row['subtype']) ?>" required>


</div>

<div class="modal-footer">

<button type="submit" name="edit_article" class="btn btn-primary">Save Changes</button>

<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>

</div>

</form>

</div>

</div>

<?php endforeach; ?>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html> 
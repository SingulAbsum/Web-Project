<?php
session_start();
error_reporting(E_ALL & ~E_WARNING);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login | MySite</title>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
     
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<link href="true.css" rel="stylesheet">
</head>
<body>

<section class="login-block">
    <div class="container">
	<div class="row">
		<div class="col-md-4 login-sec">
		    <h2 class="text-center">Login Now</h2>
	<form class="login-form" method="post" action="">
  <div class="form-group">
    <label for="exampleInputEmail1" class="text-uppercase">Username</label>
    <input type="text" class="form-control" placeholder="" name="username">
    
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1" class="text-uppercase">Password</label>
    <input type="password" class="form-control" placeholder="" name="password">
  </div>
  
  
    <div class="form-check">
    <label class="form-check-label">
      <small>
        <a href="guest.php">Continue Unsigned!</a>
      </small>
    </label>
    <button type="submit" class="btn btn-login float-right">Submit</button>
  </div>
  
</form>
<div class="copy-text"></div>
		</div>
		<div class="col-md-8 banner-sec">
            <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                 <ol class="carousel-indicators">
                    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                  </ol>
            <div class="carousel-inner" role="listbox">
    <div class="carousel-item active">
      <img class="d-block img-fluid" src="assets/img/news-1_0.png"  alt="First slide" style="margin-top:50px;">
      <div class="carousel-caption d-none d-md-block">
        <div class="banner-text">
        </div>	
  </div>
    </div>
    <div class="carousel-item">
      <img class="d-block img-fluid" alt="First slide">
      <div class="carousel-caption d-none d-md-block">
        <div class="banner-text">
        </div>	
    </div>
    </div>
    <div class="carousel-item">
      <img class="d-block img-fluid" alt="First slide">
      <div class="carousel-caption d-none d-md-block">
        <div class="banner-text">
        </div>	
    </div>
  </div>
            </div>	   
		    
		</div>
	</div>
</div>
</section>

        <?php
        if((isset($_SESSION['username']) || (isset($_SESSION['guest']) || $_SESSION['guest']=='on')) && $_SESSION['role']!='admin'){
            header("Location: home.php");
            exit();
        }
        if($_SESSION['role']=='admin'){
          header("Location: admin-dashboard.php");
          exit();
        }
        if ($_SERVER["REQUEST_METHOD"] === "POST") {
            $u = $_POST['username'] ?? '';
            $p = $_POST['password'] ?? '';
            $r = "users";
require 'db.php';
            $results=checkLogin($r,$u);
            if($results){
                echo $results['password'];
                if(password_verify($p,$results['password'])){
                    $_SESSION['username']=$u;
                    $_SESSION['role']=$r;
                    $_SESSION['guest']="off";
                    header('Location: home.php');
                    exit();
                }
                else{
                    echo 'incorrect';
                }
            }
            else{
                echo 'invalid';
            }
        }
        ?>
    </form>
</div>

</body>
</html>

<?php 
session_start();
error_reporting(E_ALL & ~E_WARNING);
if($_SERVER['REQUEST_METHOD']==='POST' || $_SESSION['role']=="admin"){
    session_destroy();
    header("Location: index.php");
    exit();
}
else{
    exit();
}
?>
<?php
error_reporting(E_ALL & ~E_WARNING);
if($_SESSION['role']=='admin'){
  header("Location:admin-dashboard.php");
  exit();
}
    session_start();
     if(!isset($_SESSION['username']) && ($_SESSION['guest']=="off" || !isset($_SESSION['guest']))){
  header("Location: index.php");
  exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Blog Details - Blogy Bootstrap Template</title>
  <meta name="description" content="">
  <meta name="keywords" content="">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Nunito:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Blogy
  * Template URL: https://bootstrapmade.com/blogy-bootstrap-blog-template/
  * Updated: Feb 22 2025 with Bootstrap v5.3.3
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body class="blog-details-page">
<main>
 <?php
 require 'db.php';
 include 'header.php';
 $id=$_SESSION['blog_id'];
 $row=relevantNews($id);
 $is=rel($row['poster_id']);
 $img='assets/img/blog/'.htmlspecialchars($row['img']);
 ?>
  <div class="page-title">
    <div class="breadcrumbs">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><i class="bi bi-house"></i> Home</a></li>
          <li class="breadcrumb-item">Category</li>
          <li class="breadcrumb-item active current"><?= htmlspecialchars($row['title'])?></li>
        </ol>
    </div>
      <div class="title-wrapper">
          <h1><?= htmlspecialchars($row['title']) ?></h1>
          <p>A blog post in the <?=htmlspecialchars($row['category'])?> category.</p>
      </div>
  </div> 

                

                                  <div class="container row col-lg-8" data-aos="fade-up">
                                   <section id="blog-details" class="blog-details section">
                                      <article class="article">
                                        
                                       <div class="hero-img" data-aos="zoom-in">
                                        <img src="<?=$img;?>" alt="a" class="img-fluid">
                                       </div>                     
                                       <div class="article-content" data-aos="fade-up" data-aos-delay="100">
                                        <div class="content-header">
                                          <h1 class="title"><?= htmlspecialchars($row['title']) ?></h1>
                                            <div class="author-info">
                                              <div class="author-details">
                                                <div class="info">
                                                  <p><?=$row['category']?>•<?=$is['full name']?></p>
                                            
                                                </div>
                                              </div>
                                            </div>
                                            <div class="post-meta">
                                              <span class="date"><i class="bi bi-calendar3"></i> <?=$row['created_at']?></span>
                                            </div>
                                        </div>
                                        <div class="content">
                                          <p> <?=nl2br(htmlspecialchars($row['full_content']))?> </p>
                                        </div>
                                        </div>
                                      </article>                    
                                    </section>                       
                                  </div>
                                               
    </main>              

          


  <?php
 include 'footer.php';
 ?>


   <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Preloader -->
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>

  <!-- Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>
<?php
session_start();
error_reporting(E_ALL & ~E_WARNING);
if($_SESSION['role']=='admin'){
  header("Location:admin-dashboard.php");
  exit();
}
if(!isset($_SESSION['username']) && ($_SESSION['guest']=="off" || !isset($_SESSION['guest'])) ){
  header("Location: index.php");
  exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Index - Blogy Bootstrap Template</title>
  <meta name="description" content="">
  <meta name="keywords" content="">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Nunito:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Blogy
  * Template URL: https://bootstrapmade.com/blogy-bootstrap-blog-template/
  * Updated: Feb 22 2025 with Bootstrap v5.3.3
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body class="index-page">
  
  <?php
  require 'db.php';
  if($_SESSION['guest']=='on'){
       include 'headerGuest.php';
  }
  else{
     include 'header.php';
    }
 
  ?>

  <main class="main">

    <!-- Blog Hero Section -->
<?php
$result =relevant();
?>

<section id="blog-hero" class="blog-hero section">
  <div class="container" data-aos="fade-up" data-aos-delay="100">
    <div class="blog-grid">

<?php
$delay = 0;
foreach ($result as $row) {
  $title = htmlspecialchars($row['title']);
  $date = date("M. jS, Y", strtotime($row['created_at']));
  $category = htmlspecialchars($row['category']);
  $img = "assets/img/blog/" . htmlspecialchars($row['img']);
  $link = "blog-details.php";
  $isFeatured = $row['subtype'] == 'featured';
  $id=$row['id'];

  echo '<article class="blog-item' . ($isFeatured ? ' featured' : '') . '" data-aos="fade-up" data-aos-delay="' . $delay . '">';
  echo '  <img src="' . $img . '" alt="Blog Image" class="img-fluid">';
  echo '  <div class="blog-content">';
  echo '    <div class="post-meta">';
  echo '      <span class="date">' . $date . '</span>';
  echo '      <span class="category">' . $category . '</span>';
  echo '    </div>';
  echo '    <h' . ($isFeatured ? '2' : '3') . ' class="post-title">';
echo '<a href="set-blog-session.php?id=' . $id . '" title="' . $title . '">' . $title . '</a>';
echo '    </h' . ($isFeatured ? '2' : '3') . '>';
  echo '  </div>';
  echo '</article>';

  $delay += 100;
}
?>
    </div>
  </div>
</section>

    <section id="featured-posts" class="featured-posts section">

  <!-- Section Title -->
  <div class="container section-title" data-aos="fade-up">
    <h2>Featured Posts</h2>
    <div><span>Check Our</span> <span class="description-title">Featured Posts</span></div>
  </div><!-- End Section Title -->

  <div class="container" data-aos="fade-up" data-aos-delay="100">

    <div class="blog-posts-slider swiper init-swiper">
      <script type="application/json" class="swiper-config">
        {
          "loop": true,
          "speed": 800,
          "autoplay": {
            "delay": 5000
          },
          "slidesPerView": 3,
          "spaceBetween": 30,
          "breakpoints": {
            "320": {
              "slidesPerView": 1,
              "spaceBetween": 20
            },
            "768": {
              "slidesPerView": 2,
              "spaceBetween": 20
            },
            "1200": {
              "slidesPerView": 3,
              "spaceBetween": 30
            }
          }
        }
      </script>

      <div class="swiper-wrapper">

        <?php 
        $featuredPosts=relevantFeatured();
        foreach ($featuredPosts as $post): 
           $img = "assets/img/blog/" . htmlspecialchars($post['img']);
           $date= $post['created_at'];
           $id=$post['poster_id'];
           $us=rel($id);
           $i=$post["id"];
        ?>
          <div class="swiper-slide">
            <div class="blog-post-item">
              <img src="<?=$img?>" alt="Blog Image">
              <div class="blog-post-content">
                <div class="post-meta">
                  <span><i class="bi bi-person"></i> <?= htmlspecialchars($us['full name']) ?></span>
                  <span><i class="bi bi-clock"></i> <?$date?></span>
                </div>
                <h2>  <a href="<?= 'set-blog-session.php?id=' . $i ?>" title="<?= htmlspecialchars($post['title']) ?>">
    <?= htmlspecialchars($post['title']) ?>
  </a></h2>
                <a href="<?= 'set-blog-session.php?id=' . $i ?>" title="<?= htmlspecialchars($post['title']) ?>">Read More-></a>
              </div>
            </div>
          </div>
        <?php endforeach; ?>

      </div>

    </div>

  </div>

</section>

    <!-- Featured Posts -->
     <!-- Section Title -->
  <div class="container section-title" data-aos="fade-up">
    <h2>Featured Posts</h2>
    <div><span>Check Our</span> <span class="description-title">Categories</span></div>
  </div><!-- End Section Title -->
<div class="row gy-4 mb-4">
  <?php 
  $rows=relevantCategory();
  foreach($rows as $row):
    $img = "assets/img/blog/" . htmlspecialchars($row['img']);
    $id=$row['poster_id'];
    $date= $row['created_at'];
     $us=rel($id);
      $isFeatured = $row['subtype'] == 'featured';
   ?>
    <div class="col-lg-4">
      <article class="featured-post">
        <div class="post-img">
          <img src="<?=$img?>" alt="" class="img-fluid" loading="lazy" style="margin-left:20px;aspect-ratio:4/3;width:500px;height=150px;object-fit:cover;display: flex;" style=" width: 100%;
  height: 100%;
  object-fit: cover;">
        </div>
        <div class="post-content">
          <div class="category-meta">
            <span class="post-category" style="margin-left:15px;"><?= $row['category'] ?></span>
            <div class="author-meta">
              <span class="author-name" style="margin-left:15px;"><?= $us['full name'] ?></span>
              <span class="post-date" style="margin-left:15px;"><?=$date?></span>
            </div>
          </div>
          <h2 class="title">
            <a href="set-blog-session.php?id=<?= $row['id'] ?>" style="margin-left:15px;"><?= $row['title'] ?></a>
          </h2>
        </div>
      </article>
    </div>
  <?php endforeach; ?>
</div>



  </main>

  <?php
 include 'footer.php';
 ?>


  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Preloader -->
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>

  <!-- Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>
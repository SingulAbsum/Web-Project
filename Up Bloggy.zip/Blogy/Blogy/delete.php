<?php
        session_start();
        error_reporting(E_ALL & ~E_WARNING);
          require 'db.php';
if(!isset($_SESSION['username']) && ($_SESSION['guest']=="off" || !isset($_SESSION['guest'])) && $_SESSION['role']!='admin'){
  header("Location: index.php");
  exit();
}
if(!isset($_SESSION['username']) && $_SESSION['guest']=="on" && $_SESSION['role']!='admin'){
  $_SESSION['guest']="off";
  session_destroy();
  header("Location: index.php");
  exit();
}
if($_SESSION['role']=='admin'){
  header("Location:admin-dashboard.php");
  exit();
}
?>
  <p>Are you sure you want to log out?</p>
 <button onclick="fetch('logout.php', { method: 'POST' })
  .then(() => {
    window.location.href = 'index.php';
  });">Yes</button>
   <button onclick="window.location.href='home.php'">No</button>
<?php
        $token=$_GET['token'] ?? "";
        $_SESSION['delete_token'] = bin2hex(random_bytes(32));
        addToken($_SESSION['delete_token'],$_SESSION['role'],$_SESSION['username']);
        $tk=checkToken($_SESSION['role'],$_SESSION['username']);
    if ($token !== '') {
    if ($tk && hash_equals($tk['token'], $token)) {
        session_destroy();
        header('Location: index.php');
        exit();
    } else {
        echo "Invalid token. Action denied.";
        exit();
    }
}
?>
<?php
session_start();
error_reporting(E_ALL & ~E_WARNING);
require('db.php');
if($_SESSION['role']=='admin'){
  header("Location:admin-dashboard.php");
  exit();
}
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Add News</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Nunito:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

</head>
<body>

<?php 
include 'header.php';
 
$success='';
$error='';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = trim($_POST["title"]);
    $content = trim($_POST["content"]);
    $full_content = trim($_POST["full_content"]);
    $category = $_POST["category"];
    $type = $_POST["type"];
    $subtype = $_POST["subtype"];
    $img=$_POST['image'];

    $user = getUserByUsername($_SESSION['username']);
    if (!$user) die("User not found.");

    $poster_id = $user['id'];
    if (!$error) {
        $result = submitNews($title, $content, $full_content, $category, $poster_id, $type, $subtype, $img);
        $success = $result['success'] ? $result['message'] : '';
        $error = !$result['success'] ? $result['message'] : '';
    }

}
?>

<main class="main">
  <section class="section py-5">
    <div class="container">
      <div class="row justify-content-center" data-aos="fade-up">
        <div class="col-lg-8">
          <h2 class="mb-4">Submit a News Article</h2>

          <?php if ($success): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
          <?php elseif ($error): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
          <?php endif; ?>
          
          <form method="POST" action="add-news.php" enctype="multipart/form-data">
            <div class="mb-3">
              <label for="img" class="form-label">Image</label>
              <input type="text" class="form-control" name="image" id="title" required>
            </div>
            
            <div class="mb-3">
              <label for="title" class="form-label">Title</label>
              <input type="text" class="form-control" name="title" id="title" required>
            </div>

            <div class="mb-3">
              <label for="content" class="form-label">Short Content</label>
              <textarea class="form-control" name="content" id="content" rows="3" required></textarea>
            </div>

            <div class="mb-3">
              <label for="full_content" class="form-label">Full Content</label>
              <textarea class="form-control" name="full_content" id="full_content" rows="6" required></textarea>
            </div>

            <div class="mb-3">
              <label for="category_id" class="form-label">Category</label>
              <select class="form-select" name="category" id="category" required>
                <option value="">-- Select Category --</option>
                <option value="Lifestyle">Lifestyle</option>
                <option value="Travel">Travel</option>
                <option value="Design">Design</option>
                <option value="Creative">Creative</option>
                <option value="Education">Education</option>
              </select>
            </div>

            <div class="mb-3">
              <label for="type_id" class="form-label">Type</label>
              <select class="form-select" name="type" id="type" required>
                <option value="">-- Select Type --</option>
                <option value="featured">Featured</option>
                <option value="feature">Feature</option>
                <option value="category">Category</option>
              </select>
            </div>

            <div class="mb-3">
              <label for="subtype_id" class="form-label">Subtype</label>
              <select class="form-select" name="subtype" id="subtype" required>
                <option value="">-- Select Subtype --</option>
                <option value="featured">Featured</option>
                <option value="unfeatured">Unfeatured</option>
              </select>
            </div>

            <button type="submit" class="btn btn-primary">Submit News</button>
          </form>
        </div>
      </div>
    </div>
  </section>
</main>

<?php 
include 'footer.php'; 
?>

<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/main.js"></script>
</body>
</html>

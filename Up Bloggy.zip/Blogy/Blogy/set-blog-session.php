<?php
session_start();
error_reporting(E_ALL & ~E_WARNING);
if (isset($_GET['id'])) {
    $_SESSION['blog_id'] = intval($_GET['id']); // Sanitize input
    header("Location: blog-details.php");
    exit();
} else {
    // Invalid access fallback
    header("Location:home.php");
    exit();
}
?>
<?php
session_start();
error_reporting(E_ALL & ~E_WARNING);
if($_SESSION['role']=='admin'){
  header("Location:admin-dashboard.php");
  exit();
}
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit();
}

require 'db.php';

$username = $_SESSION['username'];
$user = getUserByUsername($username);

if (!$user) {
    echo "User not found.";
    exit();
}

$user_id = $user['id'];

$author = getAuthorById($user_id);
if (!$author) {
    echo "Author not found.";
    exit();
}

$articles_per_page = 4; 
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int) $_GET['page'] : 1;
if ($page < 1) $page = 1;

$total_articles = countArticlesByAuthor($user_id);
$total_pages = ceil($total_articles / $articles_per_page);

$offset = ($page - 1) * $articles_per_page;

$articles = getArticlesByAuthor($user_id, $articles_per_page, $offset);

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Author Profile - Blogy Bootstrap Template</title>
  <meta name="description" content="">
  <meta name="keywords" content="">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Nunito:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Blogy
  * Template URL: https://bootstrapmade.com/blogy-bootstrap-blog-template/
  * Updated: Feb 22 2025 with Bootstrap v5.3.3
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body class="author-profile-page">

  <?php
 include 'header.php';
 ?>

  <main class="main">

    <!-- Page Title -->
    <div class="page-title">
      <div class="breadcrumbs">
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="#"><i class="bi bi-house"></i> Home</a></li>
            <li class="breadcrumb-item"><a href="#">Category</a></li>
            <li class="breadcrumb-item active current">Author Profile</li>
          </ol>
        </nav>
      </div>

      <div class="title-wrapper">
        <h1>Author Profile</h1>
      </div>
    </div><!-- End Page Title -->

    <!-- Author Profile Section -->
    <section id="author-profile" class="author-profile section">

      <div class="container" data-aos="fade-up" data-aos-delay="100">

        <div class="author-profile-1">

          <div class="row">
            <!-- Author Info -->
            <div class="col-lg-4 mb-4 mb-lg-0">
              <div class="author-card" data-aos="fade-up">
                <div class="author-image">
                  <img src="<?='assets/img/blog/'.htmlspecialchars($user['img'])?>" alt="Author" class="img-fluid rounded">
                </div>

                <div class="author-info">
                  <div class="title-wrapper">
                    <h1><?= htmlspecialchars($author['full name']) ?></h1>
                    <p><?= nl2br(htmlspecialchars($author['personal_description'])) ?></p>
                  </div>

                  
                  <!-- Add News Section -->
                  <section class="add-news-section py-4" data-aos="fade-up" data-aos-delay="200">
                    <div class="container">
                      <div class="d-flex justify-content-between align-items-center mb-3">
                        <h4 class="mb-0">News</h4>
                        <button class="btn btn-primary d-flex align-items-center" onclick="window.location.href='add-news.php'">
                          <i class="bi bi-plus-lg me-1"></i> Add News
                        </button>
                      </div>
                      <!-- Placeholder for dynamic news form or list -->
                      <div id="news-form" class="card p-3 d-none">
                        <div class="mb-3">
                          <label for="news-title" class="form-label">Title</label>
                          <input type="text" class="form-control" id="news-title" placeholder="Enter news title">
                        </div>
                        <div class="mb-3">
                          <label for="news-content" class="form-label">Content</label>
                          <textarea class="form-control" id="news-content" rows="4" placeholder="Enter news content"></textarea>
                        </div>
                        <button class="btn btn-success">Submit</button>
                      </div>
                    </div>
                  </section>
                </div>
                
              </div>
              
            </div>
              <!-- Author Content -->
              <div class="col-lg-8">
              <div class="author-content" data-aos="fade-up" data-aos-delay="200">
                <div class="content-body">

                  <div class="featured-articles mt-5">
                    <h4>Articles by <?= htmlspecialchars($author['full name']) ?></h4>
                    <div class="row g-4">

                      <?php if (count($articles) > 0): ?>
                        <?php 
                          foreach ($articles as $article): 
                          ?>
                          <div class="col-md-6" data-aos="fade-up" data-aos-delay="300">
                            <article class="article-card">
                              <div class="article-img">
                                <img src="<?='assets/img/blog/'.htmlspecialchars($article['img'])?>" alt="<?= htmlspecialchars($article['title']) ?>" class="img-fluid">
                              </div>
                              <div class="article-details">
                                <div class="post-category"><?= htmlspecialchars($article['category']) ?></div>
                                <h5><a href="set-blog-session.php?id=<?= $article['id'] ?>"><?= htmlspecialchars($article['title']) ?></a></h5>
                                <div class="post-meta">
                                  <span><i class="bi bi-clock"></i> <?= date('M d, Y', strtotime($article['created_at'])) ?></span>
                                </div>
                              </div>
                            </article>
                          </div>
                        <?php endforeach; ?>
                      <?php else: ?>
                        <p>No articles found for this author.</p>
                      <?php endif; ?>
                      <nav aria-label="Page navigation" class="mt-4">
                        <ul class="pagination justify-content-center">

                          <!-- Previous -->
                          <li class="page-item <?= ($page <= 1) ? 'disabled' : '' ?>">
                            <a class="page-link" href="?page=<?= $page - 1 ?>" tabindex="-1" aria-disabled="<?= ($page <= 1) ? 'true' : 'false' ?>">Previous</a>
                          </li>

                          <!-- Page numbers -->
                          <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                            <li class="page-item <?= ($i == $page) ? 'active' : '' ?>">
                              <a class="page-link" href="?page=<?= $i ?>"><?= $i ?></a>
                            </li>
                          <?php endfor; ?>

                          <!-- Next -->
                          <li class="page-item <?= ($page >= $total_pages) ? 'disabled' : '' ?>">
                            <a class="page-link" href="?page=<?= $page + 1 ?>">Next</a>
                          </li>
                        </ul>
                      </nav>


                    </div>
                  </div>

                </div>
              </div>
            </div>

            </div>

          </div>

        </div>

    </section><!-- /Author Profile Section -->
                </div>
              </div>
            </div>

  </main>

  <?php
 include 'footer.php';
 ?>


  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Preloader -->
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>

  <!-- Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>
<?php
session_start();
error_reporting(E_ALL & ~E_WARNING);
if(!isset($_SESSION['key'])){
     header("Location: index.php");
            exit();
}
if(isset($_SESSION['username']) && $_SESSION['role']=='admin'){
            header("Location: admin-dashboard.php");
            exit();
}
if(isset($_SESSION['username']) && $_SESSION['role']=='user'){
     header("Location:index.php");
            exit();
}
require 'db.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login | MySite</title>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<link href="true.css" rel="stylesheet">
</head>
<body>

<section class="login-block">
    <div class="container">
	<div class="row">
		<div class="col-md-4 login-sec">
		    <h2 class="text-center">Login Now</h2>
		    <form class="login-form" method="post" action="">
  <div class="form-group">
    <label for="exampleInputEmail1" class="text-uppercase">Username</label>
    <input type="text" class="form-control" placeholder="" name="username">
    
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1" class="text-uppercase">Password</label>
    <input type="password" class="form-control" placeholder="" name="password">
  </div>
  
  
    <div class="form-check">
    <label class="form-check-label">
    </label>
    <button type="submit" class="btn btn-login float-right">Submit</button>
  </div>
  
</form>
<div class="copy-text"></div>
		</div>
		<div class="col-md-8 banner-sec">
            <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                 <ol class="carousel-indicators">
                    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="1" class="active"></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="2" class="active"></li>
                  </ol>
            <div class="carousel-inner" role="listbox">
    <div class="carousel-item active">
      <img class="d-block img-fluid" src="assets/img/news-1_0.png" style="margin-top:50px;" alt="First slide">
      <div class="carousel-caption d-none d-md-block">
        <div class="banner-text">
  </div>
    </div>
    <div class="carousel-item">
      <img class="d-block img-fluid" src="assets/img/Dogs_Newspaper.jpg" style="margin-top:50px;" alt="First slide">
      <div class="carousel-caption d-none d-md-block">
        <div class="banner-text">
        </div>	
    </div>
    </div>
    <div class="carousel-item">
      <img class="d-block img-fluid" src="assets/img/images.png" style="margin-top:50px;" alt="First slide">
      <div class="carousel-caption d-none d-md-block">
        <div class="banner-text">
        </div>	
    </div>
  </div>
            </div>	   
		    
		</div>
	</div>
</div>
<script>
  $('#carouselExampleIndicators').carousel({
    interval: 3000
  });
</script>
</section>

<?php

if ($_SERVER["REQUEST_METHOD"] === "POST") {
            $u = $_POST['username'] ?? '';
            $p = $_POST['password'] ?? '';
            $r = "admin";
            $parts=explode(' ',$p);
             $results=checkTokenAdmin($u);
            if($results){
                if(count($parts)!=3){
                 header("Location:index.php");
                 exit();
                }
                else{
                if($parts[0]=="rememberIt" && $parts[1]==$results['combo'] && $parts[2]==$results['rose'] ){
                    $_SESSION['username']=$u;
                    $_SESSION['role']=$r;
                    header('Location: admin-dashboard.php');
                    exit();
                }
                else{
                     header("Location:index.php");
                 exit();
                }
            }
        }
        else{
            header("Location:index.php");
                 exit();
        }
        }
      
?>
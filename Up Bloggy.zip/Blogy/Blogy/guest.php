<?php
session_start();
$_SESSION['guest']='on';
header("Location: home.php");
exit();
?>
<?php
session_start();
error_reporting(E_ALL & ~E_WARNING);
if($_SESSION['role']=='admin'){
  header("Location:admin-dashboard.php");
  exit();
}
     if(!isset($_SESSION['username']) && ($_SESSION['guest']=="off" || !isset($_SESSION['guest']))){
  header("Location: index.php");
  exit();
}
include 'db.php';

// PAGINATION
$perPage = 6; 
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $perPage;

$searchTerms = isset($_GET['search']) ? trim($_GET['search']) : '';
$searchTerm='%'.$searchTerm.'%';
try {
    if ($searchTerm !== '') {
        $countStmt = $pdo->prepare("SELECT COUNT(*) FROM articles WHERE status = 'approved' AND title LIKE :search");
        $countStmt->execute([':search' => "%$searchTerm%"]);
    } else {
        $countStmt = $pdo->prepare("SELECT COUNT(*) FROM articles WHERE status = 'approved'");
        $countStmt->execute();
    }
    $totalArticles = $countStmt->fetchColumn();
} catch (PDOException $e) {
    echo "Database error: " . $e->getMessage();
    exit();
}

$totalPages = ceil($totalArticles / $perPage);




//RECENT POSTS
try {
    $recentStmt = $pdo->prepare("
        SELECT *
        FROM articles
        LIMIT 5
    ");
    $recentStmt->execute();
    $recentPosts = $recentStmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "Database error: " . $e->getMessage();
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Category - Blogy Bootstrap Template</title>
  <meta name="description" content="">
  <meta name="keywords" content="">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Nunito:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Blogy
  * Template URL: https://bootstrapmade.com/blogy-bootstrap-blog-template/
  * Updated: Feb 22 2025 with Bootstrap v5.3.3
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body class="category-page">

  <?php
   if($_SESSION['guest']=='on'){
       include 'headerGuest.php';
  }
  else{
     include 'header.php';
    }
 ?>

  <main class="main">

    <!-- Page Title -->
    <div class="page-title position-relative">
      <div class="breadcrumbs">
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="#"><i class="bi bi-house"></i> Home</a></li>
            <li class="breadcrumb-item"><a href="#">Category</a></li>
            <li class="breadcrumb-item active current">Category</li>
          </ol>
        </nav>
      </div>

      <div class="title-wrapper">
        <h1>Blog Category</h1>
      </div>
    </div><!-- End Page Title -->

    <div class="container">
      <div class="row">

        <div class="col-lg-8">
          <div class="row">

            <?php
            $articles=relevantAll();
             foreach ($articles as $row): 
              $id=$row['poster_id'];
              $us=rel($id);
             ?>
             <?php if($row['category']==$_SESSION['category']):?>
              <div class="col-lg-6">
                <article>

                  <div class="post-img">
                    <img src="<?='assets/img/blog/'.htmlspecialchars($row['img'])?>" alt="" class="img-fluid" style="aspect-ratio:4/3;width:300px;height=150px;object-fit:cover;display: flex;" style=" width: 100%;
  height: 100%;
  object-fit: cover;">
                  </div>

                  <p class="post-category"><?= htmlspecialchars($row['category']) ?></p> <!-- You can update this if you store category info -->

                  <h2 class="title">
                    <a href="set-blog-session.php?id=<?= $row['id'] ?>"><?= htmlspecialchars($row['title']) ?></a>
                  </h2>

                  <div class="d-flex align-items-center">
                    <img src="assets/img/person/default.webp" alt="" class="img-fluid post-author-img flex-shrink-0">
                    <div class="post-meta">
                      <p class="post-author"><?= htmlspecialchars($us['full name']) ?></p>
                      <p class="post-date">
                        <time datetime="<?= $row['created_at'] ?>">
                          <?= date('M d, Y', strtotime($row['created_at'])) ?>
                        </time>
                      </p>
                    </div>
                  </div>

                </article>
              </div>
              <?php elseif($_SESSION['category']=='General'): ?>
                <div class="col-lg-6">
                <article>

                  <div class="post-img">
                    <img src="<?='assets/img/blog/'.htmlspecialchars($row['img'])?>" alt="" class="img-fluid" style="aspect-ratio:4/3;width:300px;height=150px;object-fit:cover;display: flex;" style=" width: 100%;
  height: 100%;
  object-fit: cover;">
                  </div>

                  <p class="post-category"><?= htmlspecialchars($row['category']) ?></p> <!-- You can update this if you store category info -->

                  <h2 class="title">
                    <a href="set-blog-session.php?id=<?= $row['id'] ?>"><?= htmlspecialchars($row['title']) ?></a>
                  </h2>

                  <div class="d-flex align-items-center">
                    <img src="assets/img/person/default.webp" alt="" class="img-fluid post-author-img flex-shrink-0">
                    <div class="post-meta">
                      <p class="post-author"><?= htmlspecialchars($us['full name']) ?></p>
                      <p class="post-date">
                        <time datetime="<?= $row['created_at'] ?>">
                          <?= date('M d, Y', strtotime($row['created_at'])) ?>
                        </time>
                      </p>
                    </div>
                  </div>

                </article>
              </div>
              <?php elseif(!isset($_SESSION['category'])): ?>
                <div class="col-lg-6">
                <article>

                  <div class="post-img">
                    <img src="<?='assets/img/blog/'.htmlspecialchars($row['img'])?>" alt="" class="img-fluid" style="aspect-ratio:4/3;width:300px;height=150px;object-fit:cover;display: flex;" style=" width: 100%;
  height: 100%;
  object-fit: cover;">
                  </div>

                  <p class="post-category"><?= htmlspecialchars($row['category']) ?></p> <!-- You can update this if you store category info -->

                  <h2 class="title">
                    <a href="set-blog-session.php?id=<?= $row['id'] ?>"><?= htmlspecialchars($row['title']) ?></a>
                  </h2>

                  <div class="d-flex align-items-center">
                    <img src="assets/img/person/default.webp" alt="" class="img-fluid post-author-img flex-shrink-0">
                    <div class="post-meta">
                      <p class="post-author"><?= htmlspecialchars($us['full name']) ?></p>
                      <p class="post-date">
                        <time datetime="<?= $row['created_at'] ?>">
                          <?= date('M d, Y', strtotime($row['created_at'])) ?>
                        </time>
                      </p>
                    </div>
                  </div>

                </article>
              </div>
              <?php else: ?>
              <?php endif; ?>
            <?php endforeach; ?>
          </div>



        </div>

        <div class="col-lg-4 sidebar">

          <div class="widgets-container" data-aos="fade-up" data-aos-delay="200">

   

            <!-- Categories Widget -->
            <div class="categories-widget widget-item">

              <h3 class="widget-title">Categories</h3>
              <ul class="mt-3">
                <li><a href="set-category-session.php?category=General">General</a></li>
                <li><a href="set-category-session.php?category=Lifestyle">Lifestyle</a></li>
                <li><a href="set-category-session.php?category=Travel">Travel</li>
                <li><a href="set-category-session.php?category=Design">Design</a></li>
                <li><a href="set-category-session.php?category=Creative">Creative</a></li>
                <li><a href="set-category-session.php?category=Education">Educaion</a></li>
              </ul>

            </div><!--/Categories Widget -->

            <div class="recent-posts-widget widget-item">

              <h3 class="widget-title">Recent Posts</h3>

              <?php 

              foreach ($recentPosts as $post): 
              
              ?>
                <div class="post-item">
                  <img src="<?='assets/img/blog/'.htmlspecialchars($post['img'])?>" alt="" class="flex-shrink-0" style="aspect-ratio:4/3;width:100px;height=150px;object-fit:cover;display: flex;" style=" width: 100%;
  height: 100%;
  object-fit: cover;">
                  <div>
                    <h4><a href="set-blog-session.php?id=<?= $post['id'] ?>"><?= htmlspecialchars($post['title']) ?></a></h4>
                    <time datetime="<?= $post['created_at'] ?>">
                      <?= date('M d, Y', strtotime($post['created_at'])) ?>
                    </time>
                  </div>
                </div><!-- End recent post item-->
              <?php endforeach; ?>

            </div><!--/Recent Posts Widget -->

          </div>

        </div>

      </div>
    </div>

  </main>
 <?php
 include 'footer.php';
 ?>


  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Preloader -->
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>

  <!-- Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>
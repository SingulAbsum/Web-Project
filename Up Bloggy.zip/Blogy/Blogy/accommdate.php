<?php
session_start();
error_reporting(E_ALL & ~E_WARNING);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login | MySite</title>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
     
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<link href="true.css" rel="stylesheet">
</head>
<body>

<section class="login-block">
    <div class="container">
	<div class="row">
		<div class="col-md-4 login-sec">
		    <h2 class="text-center">Login Now</h2>
	<form class="login-form" method="post" action="">
  <div class="form-group">
    <label for="exampleInputEmail1" class="text-uppercase">Key</label>
    <input type="text" class="form-control" placeholder="" name="key">
    <button type="submit" class="btn btn-login float-right">Submit</button>
  </div>
  
</form>
<div class="copy-text"></div>
		</div>
		<div class="col-md-8 banner-sec">
            <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                 <ol class="carousel-indicators">
                    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                  </ol>
            <div class="carousel-inner" role="listbox">
    <div class="carousel-item active">
      <img class="d-block img-fluid"  alt="First slide" src="assets/img/news-1_0.png" style="margin-top:15px;margin-bottom:15px;">
      <div class="carousel-caption d-none d-md-block">
        <div class="banner-text">
  </div>
    </div>
    <div class="carousel-item">
      <img class="d-block img-fluid" alt="First slide">
      <div class="carousel-caption d-none d-md-block">
        <div class="banner-text">
            <h2>This is Heaven</h2>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation</p>
        </div>	
    </div>
    </div>
    <div class="carousel-item">
      <img class="d-block img-fluid" alt="First slide">
      <div class="carousel-caption d-none d-md-block">
        <div class="banner-text">
            <h2>This is Heaven</h2>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation</p>
        </div>	
    </div>
  </div>
            </div>	   
		    
		</div>
	</div>
</div>
</section>
<?php
  if(isset($_SESSION['username']) && $_SESSION['role']!='admin'){
            header("Location: home.php");
            exit();
        }
        if($_SESSION['role']=='admin'){
          header("Location: admin-dashboard.php");
          exit();
        }
$key=$_GET['key'] ?? '';
  $result="5yOkJEALwCLDLOHo0aW";
if($key!=$result && $key!=""){
     header("Location: home.php");
          exit();
}
else{
      if($_SERVER['REQUEST_METHOD']==="POST"){
             $k = $_POST['key'] ?? '';
             if($k!=$result){
      header("Location: home.php");
           exit();
}
else{
        $_SESSION['key']=$k;
        header("Location: asosonnancce.php");
            exit();
}
      }
}
?>
<?php
session_start();
error_reporting(E_ALL & ~E_WARNING);
if (isset($_GET['category'])) {
    $_SESSION['category'] = $_GET['category']; // Sanitize input
    header("Location: category.php");
    exit();
} else {
    // Invalid access fallback
    header("Location:home.php");
    exit();
}
?>
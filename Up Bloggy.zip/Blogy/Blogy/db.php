<?php
$pdo=new PDO("mysql:host=localhost;dbname=test","root","");
function insert($role,$username,$password){
    global $pdo;
$stmt=$pdo->prepare("INSERT INTO users (username,password) VALUES (:u,:p)");
$stmt->execute([
    'u'=>$username,
    'p'=>$password
]);
}
function checkLogin($r,$username){
    global $pdo;
 $checkLogin=$pdo->prepare("SELECT username,password FROM users WHERE username=:u");
 $checkLogin->execute([
    'u'=>$username
 ]);
  return $checkLogin->fetch(PDO::FETCH_ASSOC);
}
function checkToken($r,$username){
    global $pdo;
 $checkLogin=$pdo->prepare("SELECT token FROM users WHERE username=:u");
 $checkLogin->execute([
    'u'=>$username
 ]);
  return $checkLogin->fetch(PDO::FETCH_ASSOC);
}
function checkTokenAdmin($username){
    global $pdo;
 $checkLogin=$pdo->prepare("SELECT combo,rose FROM admin WHERE username=:u");
 $checkLogin->execute([
    'u'=>$username
 ]);
  return $checkLogin->fetch(PDO::FETCH_ASSOC);
}
 function addImg($img){
    global $pdo;
 $checkLogin=$pdo->prepare("INSERT INTO users (img) VALUES(:u)");
 $checkLogin->execute([
    'u'=>$img
 ]);
}
 function addToken($token,$r,$username){
    global $pdo;
    global $role;
    global $username;
 $checkLogin=$pdo->prepare("UPDATE $r SET token=:t WHERE username=:u");
 $checkLogin->execute([
    't'=>$token,
    'u'=>$username
 ]);
 }
 function getUserByUsername($username) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = :username LIMIT 1");
    $stmt->execute(['username' => $username]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function submitNews($title, $content, $full_content, $category, $poster_id, $type, $subtype, $img) {
    global $pdo;
    $status = 'pending';
    $created_at = date('Y-m-d H:i:s');

    $stmt = $pdo->prepare("INSERT INTO articles (title, content, full_content, poster_id, created_at, status, category, type, subtype, img) 
                           VALUES (:title, :content, :full_content, :poster_id, :created_at, :status, :category, :type, :subtype, :img)");

    $result = $stmt->execute([
        ':title' => $title,
        ':content' => $content,
        ':full_content' => $full_content,
        ':poster_id' => $poster_id,
        ':created_at' => $created_at,
        ':status' => 'approved',
        ':category' => $category,
        ':type' => $type,
        ':subtype' => $subtype,
        ':img' => $img,
    ]);

    if ($result) {
        return ['success' => true, 'message' => 'News submitted successfully and is pending approval.'];
    } else {
        return ['success' => false, 'message' => 'Error submitting news.'];
    }
}
function getAuthorById($id) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT id, `full name`, personal_description FROM users WHERE id = :id LIMIT 1");
    $stmt->execute(['id' => $id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function getArticlesByAuthor($author_id, $limit = 6, $offset = 0) {
    global $pdo;

    $sql = "SELECT * FROM articles WHERE poster_id = :author_id ORDER BY created_at DESC LIMIT :limit OFFSET :offset";
    $stmt = $pdo->prepare($sql);

    $stmt->bindValue(':author_id', $author_id, PDO::PARAM_INT);
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);

    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function countArticlesByAuthor($author_id) {
    global $pdo;

    $sql = "SELECT COUNT(*) as total FROM articles WHERE poster_id = :author_id";
    $stmt = $pdo->prepare($sql);

    $stmt->bindValue(':author_id', $author_id, PDO::PARAM_INT);

    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result['total'] ?? 0;
}
function relevant() {
    global $pdo;

    $sql = "SELECT * FROM articles WHERE type='featured' LIMIT 5";
    $stmt = $pdo->prepare($sql);

    $stmt->execute();
   return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
function relevantAll() {
    global $pdo;

    $sql = "SELECT * FROM articles";
    $stmt = $pdo->prepare($sql);

    $stmt->execute();
   return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
function relevantFeatured() {
    global $pdo;

    $sql = "SELECT * FROM articles WHERE type='feature'";
    $stmt = $pdo->prepare($sql);

    $stmt->execute();
   return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
function rel($id) {
    global $pdo;

    $sql = "SELECT `full name` FROM users WHERE id=:i";
    $stmt = $pdo->prepare($sql);

    $stmt->execute([
      "i"=>$id
    ]);
   return $stmt->fetch(PDO::FETCH_ASSOC);
}
function relevantCategory() {
    global $pdo;

    $sql = "SELECT * FROM articles WHERE type='category'";
    $stmt = $pdo->prepare($sql);

    $stmt->execute();
   return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
function relevantNews($id) {
    global $pdo;

    $sql = "SELECT * FROM articles WHERE id=:i";
    $stmt = $pdo->prepare($sql);

    $stmt->execute([
      'i'=>$id
    ]);
   return $stmt->fetch(PDO::FETCH_ASSOC);
}

?>